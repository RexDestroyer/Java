 class Main10 {
     int a;
     boolean b;
    
   private Main10() {
       a = 0;
       b = false;
   }

   public static void main(String[] args) {

    Main10 obj = new Main10();
    System.out.println("Valores padrão:");
    System.out.println("a = " + obj.a);
    System.out.println("b = " + obj.b);
   }




}
