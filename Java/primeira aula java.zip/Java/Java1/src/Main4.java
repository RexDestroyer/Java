import java.util.Scanner;

public class Main4 {

     public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("\n Digite um texto: ");
        String text1 = scan.nextLine();
        System.out.println("\n" + text1.toUpperCase() + "\n");
        scan.close();



     }






}